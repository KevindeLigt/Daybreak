using UnityEngine;
using System.Collections;

[RequireComponent(typeof(EnemyRagdollController))]
public class EnemyHealth : MonoBehaviour
{
    [Header("Stats")]
    public string enemyType = "Unknown";
    public float maxHealth = 100f;

    [Header("Training Dummy (test scene only)")]
    [Tooltip("Set before Play. Stays standing, simulates defeat, then resets. Disable for normal enemies.")]
    [SerializeField] private bool trainingDummy = false;
    [SerializeField, Min(0.1f)] private float trainingResetDelay = 1.5f;

    public bool IsTrainingDummy => trainingDummy;
    public bool TrainingDefeated { get; private set; }
    public int TrainingShotsHit { get; private set; }
    public float TrainingLastShotDamage { get; private set; }
    public float TrainingLastHealthLost { get; private set; }
    public int TrainingRevision { get; private set; }
    public bool TrainingHasOtherDamage { get; private set; }
    private float trainingResetAt;

    private void Update()
    {
        if (trainingDummy && TrainingDefeated && Time.time >= trainingResetAt)
            ResetTrainingHealth();
    }

    // Called once per target AFTER all shotgun pellets have been traced.
    // Misses do not count. Keeping colliders alive includes overkill pellets.
    public void ReceiveTrainingShot(float rawDamage)
    {
        if (!trainingDummy || TrainingDefeated || rawDamage <= 0f)
            return;

        TrainingShotsHit++;
        ApplyTrainingDamage(rawDamage);
    }

    private void ApplyTrainingDamage(float rawDamage)
    {
        TrainingLastShotDamage = rawDamage;
        TrainingLastHealthLost = Mathf.Min(currentHealth, rawDamage);
        currentHealth = Mathf.Max(0f, currentHealth - rawDamage);
        TrainingRevision++;
        if (enemyRenderer != null)
            StartHitFlash();

        if (currentHealth <= 0f)
        {
            TrainingDefeated = true;
            trainingResetAt = Time.time + Mathf.Max(0.1f, trainingResetDelay);
        }
    }

    private void ResetTrainingHealth()
    {
        StopHitFlash();
        currentHealth = Mathf.Max(1f, maxHealth);
        TrainingDefeated = false;
        TrainingShotsHit = 0;
        TrainingLastShotDamage = 0f;
        TrainingLastHealthLost = 0f;
        TrainingHasOtherDamage = false;
        TrainingRevision++;
    }

    [Header("Death Settings")]
    [Tooltip("Multiplier applied to the final hit force when the death animation becomes a ragdoll.")]
    public float deathForceMultiplier = 2f;

    [Tooltip("Safety delay used when the StumbleFall animation event is missing.")]
    public float deathRagdollFallbackDelay = 0.65f;

    [Tooltip("Safety delay used when BeginLungeRagdoll is missing from LungeImpact.")]
    public float lungeRagdollFallbackDelay = 0.55f;

    public float destroyDelay = 10f;

    [Header("Drop Settings")]
    public GameObject healthOrbPrefab;

    [Range(0f, 1f)]
    public float healthOrbDropChance = 0.10f;

    [Header("Hit Feedback")]
    public Renderer enemyRenderer;
    public Color hitColor = Color.white;
    public float flashDuration = 0.1f;

    private float currentHealth;
    private Color originalColor;

    private EnemyRagdollController ragdoll;
    private EnemyEviscerationController eviscerationController;
    private ZombieShamblerAI zombieAI;

    private Coroutine flashRoutine;
    private Coroutine deathFallbackRoutine;

    private bool isDead;
    private bool deathRagdollStarted;
    private Vector3 pendingDeathForce;

    public bool IsDead => isDead;
    public float CurrentHealth => currentHealth;

    private void Awake()
    {
        if (trainingDummy)
            maxHealth = Mathf.Max(1f, maxHealth);
        currentHealth = maxHealth;

        ragdoll = GetComponent<EnemyRagdollController>();
        eviscerationController = GetComponent<EnemyEviscerationController>();
        zombieAI = GetComponent<ZombieShamblerAI>();

        if (enemyRenderer == null)
            enemyRenderer = GetComponentInChildren<Renderer>();

        if (enemyRenderer != null)
            originalColor = enemyRenderer.material.color;
    }

    public void TakeDamage(float damage, Vector3 force)
    {
        if (trainingDummy)
        {
            if (!TrainingDefeated && damage > 0f)
            {
                // Other weapons can deplete virtual HP, but have no shot grouping.
                TrainingHasOtherDamage = true;
                ApplyTrainingDamage(damage);
            }
            return;
        }

        if (isDead || damage <= 0f)
            return;

        currentHealth = Mathf.Max(0f, currentHealth - damage);

        if (currentHealth <= 0f)
        {
            Kill(force, false);
            return;
        }

        // Flinch/Hit animation and hit stun are controlled by EnemyHitReaction.
        // EnemyHealth only owns health, death, flash, and kill bookkeeping.
        StartHitFlash();
    }

    /// <summary>
    /// Called by the shotgun's close-range evisceration check.
    /// Evisceration bypasses StumbleFall and immediately replaces the body with gibs.
    /// </summary>
    public void Eviscerate(Vector3 force)
    {
        if (trainingDummy) return;
        if (isDead)
            return;

        currentHealth = 0f;
        Kill(force, true);
    }

    /// <summary>
    /// Legacy terminal-lunge handoff; not used by ZombieShamblerAI.
    /// A hit or miss is terminal: the zombie is removed from the wave and
    /// permanently becomes a ragdoll after the impact animation.
    ///
    /// This is intentionally not registered as a player weapon kill, so it
    /// does not increase the current kill combo or persistent kill stats.
    /// </summary>
    public void BeginLungeCrashDeath(Vector3 ragdollImpulse)
    {
        if (trainingDummy) return;
        if (isDead)
            return;

        isDead = true;
        currentHealth = 0f;
        pendingDeathForce = ragdollImpulse;

        StopHitFlash();

        // The zombie is no longer an active wave enemy, even though the
        // impact animation still plays briefly before ragdoll takes over.
        GameFlowManager.Instance?.EnemyDied();

        if (lungeRagdollFallbackDelay > 0f)
        {
            deathFallbackRoutine = StartCoroutine(
                LungeRagdollFallback()
            );
        }
        else
        {
            BeginDeathRagdoll();
        }

        Destroy(gameObject, destroyDelay);
    }

    private void Kill(Vector3 force, bool wasEviscerated)
    {
        if (isDead)
            return;

        isDead = true;
        currentHealth = 0f;
        pendingDeathForce = force * deathForceMultiplier;

        StopHitFlash();

        // Shared kill bookkeeping: exactly once for both death presentations.
        GameFlowManager.Instance?.EnemyDied();
        KillComboSystem.Instance?.OnEnemyKilled();
        PlayerStatsManager.Instance?.AddKill(enemyType);
        TryDropHealthOrb();

        // Stop navigation, attacks, and idle audio. Normal death keeps the
        // Animator active long enough to play StumbleFall; evisceration
        // disables it immediately in EnemyRagdollController.
        if (zombieAI != null)
            zombieAI.BeginDeathAnimation();

        if (wasEviscerated &&
            ragdoll != null &&
            eviscerationController != null)
        {
            // This also stops AI, navigation, Animator, and the original colliders.
            ragdoll.DisableBodyForEvisceration();
            eviscerationController.Eviscerate(force);
        }
        else
        {
            BeginAnimatedDeath();
        }

        Destroy(gameObject, destroyDelay);
    }

    private void BeginAnimatedDeath()
    {
        if (zombieAI == null)
        {
            BeginDeathRagdoll();
            return;
        }

        if (deathRagdollFallbackDelay > 0f)
        {
            deathFallbackRoutine = StartCoroutine(
                DeathRagdollFallback()
            );
        }
        else
        {
            BeginDeathRagdoll();
        }
    }

    /// <summary>
    /// Called by ZombieAnimationEvents at the chosen transition frame in StumbleFall.
    /// </summary>
    public void AnimationEvent_BeginDeathRagdoll()
    {
        if (!isDead)
            return;

        BeginDeathRagdoll();
    }

    /// <summary>
    /// Called from LungeImpact when the animated crash should hand off to physics.
    /// </summary>
    public void AnimationEvent_BeginLungeRagdoll()
    {
        if (!isDead)
            return;

        BeginDeathRagdoll();
    }

    private IEnumerator DeathRagdollFallback()
    {
        yield return new WaitForSeconds(deathRagdollFallbackDelay);
        BeginDeathRagdoll();
    }

    private IEnumerator LungeRagdollFallback()
    {
        yield return new WaitForSeconds(lungeRagdollFallbackDelay);
        BeginDeathRagdoll();
    }

    private void BeginDeathRagdoll()
    {
        if (deathRagdollStarted)
            return;

        deathRagdollStarted = true;

        if (deathFallbackRoutine != null)
        {
            StopCoroutine(deathFallbackRoutine);
            deathFallbackRoutine = null;
        }

        if (ragdoll != null)
        {
            ragdoll.EnableRagdoll(pendingDeathForce);
        }
        else
        {
            Debug.LogWarning(
                $"{name}: Cannot begin death ragdoll because EnemyRagdollController is missing.",
                this
            );
        }
    }

    private void StartHitFlash()
    {
        if (enemyRenderer == null)
            return;

        if (flashRoutine != null)
            StopCoroutine(flashRoutine);

        flashRoutine = StartCoroutine(Flash());
    }

    private void StopHitFlash()
    {
        if (flashRoutine != null)
        {
            StopCoroutine(flashRoutine);
            flashRoutine = null;
        }

        if (enemyRenderer != null)
            enemyRenderer.material.color = originalColor;
    }

    private IEnumerator Flash()
    {
        enemyRenderer.material.color = hitColor;

        yield return new WaitForSeconds(flashDuration);

        if (!isDead && enemyRenderer != null)
            enemyRenderer.material.color = originalColor;

        flashRoutine = null;
    }

    public Transform GetClosestRagdollBone(Vector3 hitPoint)
    {
        if (ragdoll == null || ragdoll.ragdollBodies == null)
            return null;

        float closestDistance = float.MaxValue;
        Transform closestBone = null;

        foreach (Rigidbody body in ragdoll.ragdollBodies)
        {
            if (body == null)
                continue;

            float distance = Vector3.Distance(
                body.transform.position,
                hitPoint
            );

            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestBone = body.transform;
            }
        }

        return closestBone;
    }

    private void TryDropHealthOrb()
    {
        if (healthOrbPrefab == null)
            return;

        if (Random.value > healthOrbDropChance)
            return;

        Instantiate(
            healthOrbPrefab,
            transform.position + Vector3.up * 0.5f,
            Quaternion.identity
        );
    }
}
