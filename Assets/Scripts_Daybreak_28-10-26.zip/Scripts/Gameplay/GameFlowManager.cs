using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class GameFlowManager : MonoBehaviour
{
    public static GameFlowManager Instance { get; private set; }

    [Header("Wave Settings")]
    public GameObject[] enemyPrefabs;
    public int startingEnemiesPerWave = 5;

    [Tooltip("Extra enemies added to each run-wide wave. Region transitions keep this progression.")]
    [Min(0)] public int enemiesAddedPerWave = 2;

    [Tooltip("Used only when the active region has no Curse Objective assigned.")]
    public int maxWaves = 5;

    public float timeBetweenWaves = 3f;
    [Tooltip("Fixed interval used when Use Paced Spawning is disabled.")]
    public float spawnDelay = 0.3f;

    [Header("Wave Pacing")]
    [SerializeField] private bool usePacedSpawning = true;
    [Tooltip("Spawning window in seconds, excluding the warning. A full room pauses this clock; clearing survivors can take longer.")]
    [SerializeField, Min(1f)] private float waveSpawnDuration = 35f;
    [Tooltip("X: progress through the spawning window (0 to 1). Y: relative spawning pressure. Higher sections receive more of the wave's fixed enemy total.")]
    [SerializeField] private AnimationCurve spawnPressureCurve = WaveSpawnSchedule.CreateDefaultCurve();
    [Tooltip("Maximum living wave enemies in the room. At the limit, paced spawning and its clock wait for a kill. Zero disables the limit.")]
    [SerializeField, Min(0)] private int maxConcurrentEnemies = 8;
    [Tooltip("Warning time before each wave. Optional events below can play sound or VFX. Zero starts immediately.")]
    [SerializeField, Min(0f)] private float waveWarningDuration = 2.5f;

    [Header("Wave Feedback (optional)")]
    public UnityEvent onWaveWarning = new UnityEvent();
    public UnityEvent onWaveStarted = new UnityEvent();
    [Tooltip("All spawn attempts are finished, but surviving enemies may still need to be killed.")]
    public UnityEvent onWaveSpawningFinished = new UnityEvent();

    [Header("Curse Objective Flow")]
    [SerializeField] private bool useCurseObjectiveFlow = true;

    [Tooltip("Pause after killing the final enemy before revealing the next Root Heart.")]
    [SerializeField, Min(0f)] private float rootHeartReleaseDelay = 0.75f;

    [Tooltip("Pause after depositing a Root Heart before the next wave begins.")]
    [SerializeField, Min(0f)] private float nextWaveAfterDepositDelay = 1.5f;

    [Tooltip("Pause after opening a gate and activating a new region before its first wave begins.")]
    [SerializeField, Min(0f)] private float newRegionStartDelay = 1f;

    [Header("References")]
    public UIManager uiManager;

    [Header("Heart Encounter Prototype")]
    [Tooltip("Wave enemies gather near the next heart when they cannot detect the player. The last few pursue the player regardless of detection range.")]
    [SerializeField] private bool useHeartEncounterFocus = true;
    [SerializeField, Min(0f)] private float heartGatherRadius = 3f;
    [SerializeField, Min(1)] private int finalEnemiesHuntPlayer = 3;
    [Tooltip("Temporary screen marker: previews the heart, announces its release, then points back to the Curse Anchor.")]
    [SerializeField] private bool showHeartEncounterGuide = true;
    [Tooltip("Optional. Leave empty to use the camera tagged MainCamera.")]
    [SerializeField] private Camera heartGuideCamera;

    // Run-wide wave number. This never resets when moving between regions.
    private int currentWave;

    // Wave number inside the currently active region. This resets on region transition.
    private int currentRegionWave;

    private int aliveEnemies;
    private int enemiesThisWave;
    [SerializeField] private int pendingSpawns;
    [SerializeField] private float waveSpawnElapsed;
    private bool gameActive;
    private bool isSpawningWave;
    private bool isWaitingForNextWave;
    private bool isWaitingForHeartDeposit;
    private bool hasStarted;

    private MapRegion currentRegion;
    private CurseObjectiveController currentObjective;
    private RegionManager subscribedRegionManager;
    private Coroutine progressionCoroutine;
    private Coroutine spawnCoroutine;
    private readonly List<ZombieAIController> waveControllers = new List<ZombieAIController>();
    private Transform heartGatheringPoint;
    private RootHeartEncounterGuide heartGuide;
    private bool finalHuntOrdered;
    private int encounterVersion;

    public int CurrentWave => currentWave;
    public int CurrentRegionWave => currentRegionWave;
    public int AliveEnemies => aliveEnemies;
    // AliveEnemies retains the existing "enemies left in this wave" contract,
    // including arrivals still pending. The limit uses only living arrivals.
    public int LivingEnemies => Mathf.Max(0, aliveEnemies - pendingSpawns);
    public int PendingSpawns => pendingSpawns;
    public bool GameActive => gameActive;
    public bool IsWaitingForHeartDeposit => isWaitingForHeartDeposit;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        if (!SceneLoader.IsLoading) Time.timeScale = 1f;
    }

    private void Start()
    {
        if (uiManager == null)
            uiManager = FindObjectOfType<UIManager>();

        ResetGameState();
        SubscribeToRegionManager();
        StartCoroutine(StartGameRoutine());
        FindObjectOfType<ShrineSpawnerManager>()?.SpawnShrinesForRun();

        UIManager.Instance?.ClearAllStatusEffects();
        // LevelSceneSetup restores/initializes run bonuses after all Start methods.
        if (LevelSceneSetup.Instance == null && (RunState.Instance == null || !RunState.Instance.AwaitingArrival))
        {
            PlayerWeaponStats.Instance?.ResetRunStats();
            PlayerStatsManager.GetOrCreate().BeginRun();
        }
    }

    private void OnDestroy()
    {
        StopSpawningWave();
        StopProgressionCoroutine();
        ClearWaveOrders();
        UnsubscribeFromRegionManager();
        UnbindCurrentObjective();
        if (Instance == this) Instance = null;
    }

    private void ResetGameState()
    {
        currentWave = 0;
        currentRegionWave = 0;
        aliveEnemies = 0;
        enemiesThisWave = 0;
        pendingSpawns = 0;
        waveSpawnElapsed = 0f;
        gameActive = true;
        isSpawningWave = false;
        isWaitingForNextWave = false;
        isWaitingForHeartDeposit = false;
        hasStarted = false;
    }

    private IEnumerator StartGameRoutine()
    {
        yield return null;
        LevelSceneSetup setup = LevelSceneSetup.Instance;
        if (setup == null && RunState.Instance != null && RunState.Instance.AwaitingArrival)
        {
            Debug.LogError("Add LevelSceneSetup to this gameplay scene. Its encounter is paused until the run can be restored.");
            yield break;
        }
        if (setup != null)
        {
            while (!setup.IsReady)
            {
                if (!string.IsNullOrEmpty(setup.InitializationError)) yield break;
                yield return null;
            }
            currentWave = RunState.Instance.GlobalWave;
            uiManager?.UpdateWave(currentWave);
        }
        // Do not spawn arrivals under the transition overlay.
        while (SceneLoader.IsLoading) yield return null;
        // Allows RegionManager, regional runtime objects, UI, and objectives to initialize.
        yield return new WaitForSeconds(0.2f);

        SubscribeToRegionManager();
        hasStarted = true;

        MapRegion startingRegion = RegionManager.Instance != null
            ? RegionManager.Instance.CurrentRegion
            : null;

        BeginRegionEncounter(startingRegion, 0f);
    }

    private void SubscribeToRegionManager()
    {
        RegionManager manager = RegionManager.Instance;
        if (manager == subscribedRegionManager)
            return;

        UnsubscribeFromRegionManager();
        subscribedRegionManager = manager;

        if (subscribedRegionManager != null)
            subscribedRegionManager.CurrentRegionChanged += HandleCurrentRegionChanged;
    }

    private void UnsubscribeFromRegionManager()
    {
        if (subscribedRegionManager != null)
            subscribedRegionManager.CurrentRegionChanged -= HandleCurrentRegionChanged;

        subscribedRegionManager = null;
    }

    private void HandleCurrentRegionChanged(MapRegion region)
    {
        if (!hasStarted || !gameActive)
            return;

        BeginRegionEncounter(region, newRegionStartDelay);
    }

    private void BeginRegionEncounter(MapRegion region, float delay)
    {
        encounterVersion++;
        StopSpawningWave();
        ClearWaveOrders();
        heartGuide?.ClearGuide();
        StopProgressionCoroutine();
        UnbindCurrentObjective();

        currentRegion = region;
        currentRegionWave = 0;
        aliveEnemies = 0;
        enemiesThisWave = 0;
        pendingSpawns = 0;
        waveSpawnElapsed = 0f;
        isSpawningWave = false;
        isWaitingForNextWave = false;
        isWaitingForHeartDeposit = false;

        uiManager?.UpdateEnemyCount(0, 0);

        if (currentRegion == null)
        {
            Debug.LogError("GameFlowManager cannot begin an encounter because RegionManager has no Current Region.");
            return;
        }

        currentObjective = currentRegion.CurseObjective;
        BindCurrentObjective();

        if (currentRegion.IsCompleted)
        {
            Debug.LogWarning($"GameFlowManager was asked to begin completed region: {currentRegion.RegionName}");
            return;
        }

        progressionCoroutine = StartCoroutine(BeginRegionAfterDelay(delay));
    }

    private IEnumerator BeginRegionAfterDelay(float delay)
    {
        if (delay > 0f)
            yield return new WaitForSeconds(delay);

        progressionCoroutine = null;

        if (!gameActive)
            yield break;

        StartNextWave();
    }

    private void BindCurrentObjective()
    {
        if (currentObjective != null)
            currentObjective.HeartDepositedRuntime += HandleHeartDeposited;
    }

    private void UnbindCurrentObjective()
    {
        if (currentObjective != null)
            currentObjective.HeartDepositedRuntime -= HandleHeartDeposited;

        currentObjective = null;
    }

    private void StartNextWave()
    {
        if (!gameActive || isWaitingForHeartDeposit || isSpawningWave)
            return;

        if (!HasValidSpawnSetup())
        {
            Debug.LogError("Wave could not start. Check RegionManager.CurrentRegion, its active spawners, enemy prefabs, and encounter state.");
            return;
        }

        PrepareHeartEncounter();
        currentWave++;
        currentRegionWave++;

        // Enemy pressure scales across the whole run instead of restarting
        // when the player enters a new region.
        enemiesThisWave = Mathf.Max(1, startingEnemiesPerWave +
            (currentWave - 1) * Mathf.Max(0, enemiesAddedPerWave));
        aliveEnemies = enemiesThisWave;
        pendingSpawns = enemiesThisWave;
        waveSpawnElapsed = 0f;
        isSpawningWave = true;
        isWaitingForNextWave = false;

        uiManager?.UpdateWave(currentWave);
        uiManager?.UpdateEnemyCount(aliveEnemies, enemiesThisWave);

        int version = encounterVersion;
        Coroutine routine = StartCoroutine(SpawnWaveRoutine(version));
        // An Inspector feedback event can synchronously end or replace the
        // encounter. Do not overwrite a newer wave's coroutine in that case.
        if (IsCurrentWave(version) && isSpawningWave) spawnCoroutine = routine;
    }

    private IEnumerator SpawnWaveRoutine(int version)
    {
        int failedSpawns = 0;
        int plannedSpawns = enemiesThisWave;
        bool paced = usePacedSpawning;
        float[] spawnTimes = paced
            ? WaveSpawnSchedule.Build(plannedSpawns, Mathf.Max(1f, waveSpawnDuration), spawnPressureCurve)
            : WaveSpawnSchedule.BuildFixed(plannedSpawns, Mathf.Max(0.02f, spawnDelay));

        onWaveWarning?.Invoke();
        if (!IsCurrentWave(version)) yield break;
        if (waveWarningDuration > 0f)
            yield return new WaitForSeconds(waveWarningDuration);
        if (!IsCurrentWave(version)) yield break;
        onWaveStarted?.Invoke();
        if (!IsCurrentWave(version)) yield break;

        int attemptedSpawns = 0;
        float nextSpawnAllowedAt = Time.time;

        while (attemptedSpawns < plannedSpawns)
        {
            if (!IsCurrentWave(version)) yield break;

            bool roomFull = paced && maxConcurrentEnemies > 0 &&
                LivingEnemies >= maxConcurrentEnemies;
            if (!roomFull && waveSpawnElapsed >= spawnTimes[attemptedSpawns] &&
                Time.time >= nextSpawnAllowedAt)
            {
                // Reserve this living arrival before Instantiate: an OnEnable
                // callback can report a death synchronously during creation.
                pendingSpawns--;
                attemptedSpawns++;
                if (!SpawnEnemy())
                {
                    failedSpawns++;
                    aliveEnemies = Mathf.Max(0, aliveEnemies - 1);
                    uiManager?.UpdateEnemyCount(aliveEnemies, enemiesThisWave);
                }
                if (!IsCurrentWave(version)) yield break;

                // One arrival per frame and a short minimum interval prevent
                // catch-up bursts after a slow frame. Normal timings come from
                // the curve; this is only a lower bound.
                nextSpawnAllowedAt = Time.time + (paced ? 0.15f : 0.02f);
                if (attemptedSpawns >= plannedSpawns) break;
            }

            roomFull = paced && maxConcurrentEnemies > 0 &&
                LivingEnemies >= maxConcurrentEnemies;
            yield return null;
            if (!IsCurrentWave(version)) yield break;
            if (!roomFull) waveSpawnElapsed += Time.deltaTime;
        }

        if (!IsCurrentWave(version)) yield break;

        if (failedSpawns > 0)
        {
            Debug.LogWarning($"{failedSpawns} enemies could not be spawned during Wave {currentWave}.");
        }

        spawnCoroutine = null;
        isSpawningWave = false;
        if (failedSpawns >= plannedSpawns)
        {
            Debug.LogError("The entire wave failed to spawn. Progression has been paused instead of falsely completing the wave.");
            yield break;
        }

        onWaveSpawningFinished?.Invoke();
        if (!IsCurrentWave(version)) yield break;
        CheckFinalEnemies();
        if (aliveEnemies <= 0) HandleWaveCleared();
    }

    private bool IsCurrentWave(int version) => gameActive && version == encounterVersion;

    private void StopSpawningWave()
    {
        if (spawnCoroutine != null) StopCoroutine(spawnCoroutine);
        spawnCoroutine = null;
        aliveEnemies = Mathf.Max(0, aliveEnemies - pendingSpawns);
        pendingSpawns = 0;
        isSpawningWave = false;
    }

    [ContextMenu("Restore Default Spawn Pressure Curve")]
    private void RestoreDefaultSpawnPressureCurve()
    {
        spawnPressureCurve = WaveSpawnSchedule.CreateDefaultCurve();
    }

    private bool SpawnEnemy()
    {
        if (RegionManager.Instance == null)
        {
            Debug.LogError("No RegionManager exists in the scene.");
            return false;
        }

        EnemySpawner[] activeSpawners = RegionManager.Instance.GetCurrentRegionSpawners();
        if (activeSpawners.Length == 0)
        {
            Debug.LogWarning("No active spawners were found in the current combat region.");
            return false;
        }

        if (enemyPrefabs == null || enemyPrefabs.Length == 0)
        {
            Debug.LogError("GameFlowManager has no enemy prefabs assigned.");
            return false;
        }

        EnemySpawner chosenSpawner = activeSpawners[Random.Range(0, activeSpawners.Length)];
        GameObject chosenPrefab = enemyPrefabs[Random.Range(0, enemyPrefabs.Length)];

        if (chosenSpawner == null || chosenPrefab == null)
        {
            Debug.LogWarning("A selected enemy spawner or enemy prefab was null.");
            return false;
        }

        EnemyHealth prefabHealth = chosenPrefab.GetComponent<EnemyHealth>();
        if (prefabHealth != null && prefabHealth.IsTrainingDummy)
        {
            Debug.LogWarning("A training dummy was selected as a wave enemy. Use a combat prefab; this spawn will not count toward the wave.");
            return false;
        }

        GameObject spawned = Instantiate(
            chosenPrefab,
            chosenSpawner.spawnPoint.position,
            chosenSpawner.spawnPoint.rotation);

        if (heartGatheringPoint != null)
        {
            ZombieAIController controller = spawned.GetComponent<ZombieAIController>();
            if (controller != null)
            {
                Vector2 offset = Random.insideUnitCircle * Mathf.Max(0f, heartGatherRadius);
                controller.AssignEncounterFocus(heartGatheringPoint, new Vector3(offset.x, 0f, offset.y));
                waveControllers.Add(controller);
            }
        }

        return true;
    }

    private bool HasValidSpawnSetup()
    {
        if (RegionManager.Instance == null)
            return false;

        if (RegionManager.Instance.CurrentRegion == null)
            return false;

        if (RegionManager.Instance.GetCurrentRegionSpawners().Length == 0)
            return false;

        return enemyPrefabs != null && enemyPrefabs.Length > 0;
    }

    public void EnemyDied()
    {
        // Pending arrivals cannot die. Ignore notifications when no living
        // arrival is registered instead of subtracting from future spawns.
        if (!gameActive || LivingEnemies <= 0)
            return;

        aliveEnemies = Mathf.Max(0, aliveEnemies - 1);
        uiManager?.UpdateEnemyCount(aliveEnemies, enemiesThisWave);

        CheckFinalEnemies();

        // Do not complete the wave while more enemies are still waiting to spawn.
        if (aliveEnemies <= 0 && !isSpawningWave)
            HandleWaveCleared();
    }

    private void HandleWaveCleared()
    {
        if (!gameActive || isWaitingForNextWave || isWaitingForHeartDeposit)
            return;

        if (useCurseObjectiveFlow && currentObjective != null && !currentObjective.IsCompleted)
        {
            isWaitingForNextWave = true;
            isWaitingForHeartDeposit = true;
            progressionCoroutine = StartCoroutine(ReleaseRootHeartAfterDelay());
            return;
        }

        // Backwards-compatible fallback for a region that has no Curse Objective.
        if (currentRegionWave >= maxWaves)
        {
            WinGame();
            return;
        }

        isWaitingForNextWave = true;
        progressionCoroutine = StartCoroutine(NextWaveDelay(timeBetweenWaves));
    }

    private IEnumerator ReleaseRootHeartAfterDelay()
    {
        if (rootHeartReleaseDelay > 0f)
            yield return new WaitForSeconds(rootHeartReleaseDelay);

        progressionCoroutine = null;

        if (!gameActive || currentObjective == null)
            yield break;

        if (!currentObjective.ReleaseNextHeart())
        {
            Debug.LogError(
                "The wave was cleared, but the next Root Heart could not be released. " +
                "Check Wave Controlled Pickups, Required Hearts, and the pickup array.");
        }
    }

    private void HandleHeartDeposited(CurseObjectiveController objective)
    {
        if (!gameActive || objective == null || objective != currentObjective)
            return;

        if (!isWaitingForHeartDeposit)
        {
            Debug.LogWarning("A Root Heart was deposited while GameFlowManager was not waiting for one.");
            return;
        }

        isWaitingForHeartDeposit = false;
        isWaitingForNextWave = false;
        heartGuide?.ClearGuide();

        if (objective.IsCompleted)
        {
            CompleteCurrentRegionalEncounter();
            return;
        }

        progressionCoroutine = StartCoroutine(NextWaveDelay(nextWaveAfterDepositDelay));
    }

    private IEnumerator NextWaveDelay(float delay)
    {
        if (delay > 0f)
            yield return new WaitForSeconds(delay);

        progressionCoroutine = null;

        if (!gameActive)
            yield break;

        StartNextWave();
    }

    private void CompleteCurrentRegionalEncounter()
    {
        encounterVersion++;
        StopSpawningWave();
        ClearWaveOrders();
        heartGuide?.ClearGuide();
        StopProgressionCoroutine();
        aliveEnemies = 0;
        enemiesThisWave = 0;
        pendingSpawns = 0;
        isSpawningWave = false;
        isWaitingForHeartDeposit = false;
        isWaitingForNextWave = false;

        uiManager?.UpdateEnemyCount(0, 0);

        MapRegion completedRegion = currentRegion;

        if (RegionManager.Instance == null || !RegionManager.Instance.CompleteCurrentRegion())
        {
            Debug.LogError("The Curse Objective completed, but the current MapRegion could not be completed.");
            return;
        }

        if (completedRegion != null && completedRegion.CompleteRunWhenFinished)
        {
            WinGame();
            return;
        }

        Debug.Log(
            $"Regional encounter completed: {completedRegion?.RegionName}. " +
            "Its spawners are disabled and its exit gate is now unlocked.");
    }

    private void StopProgressionCoroutine()
    {
        if (progressionCoroutine == null)
            return;

        StopCoroutine(progressionCoroutine);
        progressionCoroutine = null;
    }

    private void PrepareHeartEncounter()
    {
        ClearWaveOrders();
        heartGuide?.ClearGuide();
        if (!useHeartEncounterFocus || !useCurseObjectiveFlow || currentObjective == null ||
            !currentObjective.WaveControlledPickups) return;

        RootHeartPickup pickup = currentObjective.NextHeartPickup;
        heartGatheringPoint = currentObjective.NextHeartGatheringPoint;
        if (pickup == null || heartGatheringPoint == null)
        {
            Debug.LogWarning("No next Root Heart is assigned for this wave. Check the objective's pickup array.");
            return;
        }
        if (showHeartEncounterGuide)
        {
            if (heartGuide == null) heartGuide = gameObject.AddComponent<RootHeartEncounterGuide>();
            heartGuide.Bind(this, currentObjective, pickup.transform, heartGuideCamera);
        }
    }

    private void CheckFinalEnemies()
    {
        if (!gameActive || isSpawningWave || finalHuntOrdered || heartGatheringPoint == null ||
            aliveEnemies <= 0 || aliveEnemies > Mathf.Max(1, finalEnemiesHuntPlayer)) return;
        finalHuntOrdered = true;
        foreach (ZombieAIController controller in waveControllers)
            if (controller != null) controller.PursuePlayerForEncounter();
    }

    private void ClearWaveOrders()
    {
        foreach (ZombieAIController controller in waveControllers)
            if (controller != null) controller.ClearEncounterOrders();
        waveControllers.Clear();
        heartGatheringPoint = null;
        finalHuntOrdered = false;
    }

    public void PlayerDied()
    {
        LoseGame();
    }

    public void WinGame()
    {
        if (!gameActive)
            return;

        gameActive = false;
        PlayerStatsManager.GetOrCreate().FinishRun(ScoredRunResult.Completed);
        StopSpawningWave();
        StopProgressionCoroutine();
        heartGuide?.ClearGuide();
        Time.timeScale = 0f;
        uiManager?.ShowGameOver(true);
    }

    public void LoseGame()
    {
        if (!gameActive)
            return;

        gameActive = false;
        PlayerStatsManager.GetOrCreate().FinishRun(ScoredRunResult.Died);
        StopSpawningWave();
        StopProgressionCoroutine();
        heartGuide?.ClearGuide();
        Time.timeScale = 0f;
        uiManager?.ShowGameOver(false);
    }
}

/// <summary>
/// Converts relative spawn pressure into a finite set of arrival times.
/// Kept in this file so replacing GameFlowManager.cs is the only install step.
/// The total enemy count is fixed; the curve distributes that count over time.
/// </summary>
internal static class WaveSpawnSchedule
{
    public static AnimationCurve CreateDefaultCurve() => new AnimationCurve(
        new Keyframe(0f, 0.2f),
        new Keyframe(0.2f, 0.4f),
        new Keyframe(0.55f, 1f),
        new Keyframe(0.75f, 0.8f),
        new Keyframe(1f, 0.2f));

    public static float[] BuildFixed(int count, float interval)
    {
        float[] times = new float[Mathf.Max(0, count)];
        for (int i = 0; i < times.Length; i++) times[i] = i * interval;
        return times;
    }

    public static float[] Build(int count, float duration, AnimationCurve curve)
    {
        if (count <= 0) return new float[0];
        if (count == 1) return new float[1];

        const int samples = 256;
        float[] cumulative = new float[samples + 1];
        float previous = Weight(curve, 0f);
        for (int i = 1; i <= samples; i++)
        {
            float weight = Weight(curve, (float)i / samples);
            cumulative[i] = cumulative[i - 1] + (previous + weight) * 0.5f;
            previous = weight;
        }

        float total = cumulative[samples];
        float[] times = new float[count];
        duration = Mathf.Max(0f, duration);
        int sample = 1;
        for (int i = 0; i < count; i++)
        {
            // Midpoints of equal portions of area avoid a mandatory late
            // straggler exactly at the end of the spawning window.
            float fraction = (i + 0.5f) / count;
            if (total <= 0.0001f)
            {
                // Empty/all-zero curves fall back to uniform arrivals.
                times[i] = fraction * duration;
                continue;
            }

            float targetArea = fraction * total;
            while (sample < samples && cumulative[sample] < targetArea) sample++;
            float sectionArea = cumulative[sample] - cumulative[sample - 1];
            float sectionFraction = sectionArea > 0f
                ? (targetArea - cumulative[sample - 1]) / sectionArea : 0f;
            times[i] = ((sample - 1 + sectionFraction) / samples) * duration;
        }
        return times;
    }

    private static float Weight(AnimationCurve curve, float time)
    {
        if (curve == null || curve.length == 0) return 1f;
        float value = curve.Evaluate(time);
        if (float.IsNaN(value) || float.IsInfinity(value)) return 0f;
        return Mathf.Max(0f, value);
    }
}
